<script type="text/javascript" src="/Users/Scott/.rvm/gems/ruby-1.9.2-p290/gems/jquery-rails-2.0.2/vendor/assets/javascripts/jquery.js"></script>;
<script type="text/javascript" src="/Users/Scott/.rvm/gems/ruby-1.9.2-p290/gems/jquery-rails-2.0.2/vendor/assets/javascripts/jquery_ujs.js"></script>;
<script type="text/javascript" src="/Users/Scott/ballot/app/assets/javascripts/location.js"></script>;
<script type="text/javascript" src="/Users/Scott/ballot/app/assets/javascripts/maps.js"></script>;
<script type="text/javascript" src="/Users/Scott/ballot/app/assets/javascripts/application.js"></script>;
